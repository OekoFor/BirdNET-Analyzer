# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['birdnet_analyzer_4rpi']

package_data = \
{'': ['*'],
 'birdnet_analyzer_4rpi': ['checkpoints/*',
                           'checkpoints/V2.2/*',
                           'checkpoints/V2.2/BirdNET_GLOBAL_3K_V2.2_Model/*',
                           'checkpoints/V2.2/BirdNET_GLOBAL_3K_V2.2_Model/variables/*',
                           'labels/V2.0/*',
                           'labels/V2.1/*',
                           'labels/V2.2/*']}

install_requires = \
['librosa>=0.9.2,<0.10.0', 'tflite-runtime>=2.10.0,<3.0.0']

setup_kwargs = {
    'name': 'birdnet-analyzer-4rpi',
    'version': '0.1.0',
    'description': 'Python package for BirdNET-Analyzer using model V2.2',
    'long_description': '# BirdNET-Analyzer-4RPi\nPython package of the [BirdNET-Analyzer](https://github.com/kahst/BirdNET-Analyzer) for usage on Raspberry Pi.\n\nThis package was tested with `python=3.9` on `TUXEDO OS 22.04 (x64)` and `RASPBERRY PI OS LITE 11 bullseye (x64)`.\n\n\n## Installation\n\n### 1. Install system dependencies\n\n```sh\nsudo apt install pip ffmpeg\n```\n\n### 2. Clone or download this repository\n\n### 3. Install the package via pip from .whl\nBy running the following command the package will be installed globally for the user running the ecoPi.\n```sh\npip install <BirdNET-Analyzer-4RPi>/dist/birdnet_analyzer_4rpi-<your version>.whl\n```\n\n\n## Usage\n',
    'author': 'Florian Stehr',
    'author_email': 'florian.stehr@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
